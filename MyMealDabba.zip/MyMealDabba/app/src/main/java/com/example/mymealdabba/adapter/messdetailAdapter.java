package com.example.mymealdabba.adapter;

public class messdetailAdapter {
}
