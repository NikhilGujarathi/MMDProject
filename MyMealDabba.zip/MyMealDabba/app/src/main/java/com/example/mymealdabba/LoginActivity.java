package com.example.mymealdabba;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText txtMobile;
    Button btnSignin;
    TextView signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        txtMobile=findViewById(R.id.txtMobile);
        btnSignin=findViewById(R.id.btnSignin);
        signup=findViewById(R.id.signup);

        btnSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                 String mobile=txtMobile.getText().toString();
//                if (mobile.isEmpty()){
//                    txtMobile.setError("Enter The Mobile No");
//                    txtMobile.requestFocus();
//
//                }else  if (mobile.equals("") || mobile.equals(null) || mobile.length() > 10 || mobile.length() < 9) {
//                    txtMobile.setError("Enter Only 10 digit number");
//                    return;
//                }else {

//                    AlertDialog.Builder builder = new AlertDialog.Builder(LoginActivity.this);
//                    View view1 = getLayoutInflater().inflate(R.layout.otp_page, null);
//                    EditText otpedittext = (EditText) view1.findViewById(R.id.otpedittext);
//                    Button verifyotp = (Button) view1.findViewById(R.id.verifyotp);
//
//                    verifyotp.setOnClickListener(new View.OnClickListener() {
//                        @Override
//                        public void onClick(View view) {
//                            if (!otpedittext.getText().toString().isEmpty()) {
//                                Toast.makeText(LoginActivity.this, "Successfully", Toast.LENGTH_SHORT).show();
//                            } else {
//                                Toast.makeText(LoginActivity.this, "Successfully", Toast.LENGTH_SHORT).show();
//                            }
//
//                        }
//                    });
//
//                    builder.setView(view1);
//                    AlertDialog dialog = builder.create();
//                    dialog.show();
                    Intent intent = new Intent(getApplicationContext(), NavigationActivity.class);
                   startActivity(intent);
//                }
            }
        });


signup.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent intent=new Intent(getApplicationContext(),SignUpActivity.class);
        startActivity(intent);
    }
});
    }
}